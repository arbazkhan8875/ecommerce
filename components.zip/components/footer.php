</div>

<script src="/phpclass/assets/js/jquery.min.js"></script>
<script src="/phpclass/assets/js/bootstrap.bundle.min.js"></script>
<script src="/phpclass/assets/js/slimscroll.min.js"></script>
<script src="/phpclass/assets/js/slimscroll.init.js"></script>
<script src="/phpclass/assets/js/moment.min.js"></script>
<script src="/phpclass/assets/js/jquery-ui.min.js"></script>
<script src="/phpclass/assets/js/app.min.js"></script>
</body>

</html>